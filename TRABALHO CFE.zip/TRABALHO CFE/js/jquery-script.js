//efeito de esconder formulário de cadastro
/*padrão isso aq -----> $(document).ready(function(){}); esse $botao cadastrar ai é como se fosse o document.getElementByID('botao-cadastrar').click()*/


$(document).ready(function(){

    $("#botao-cadastrar").click(function(){

        $("#form-cadastrar").slideToggle("slow");
        $("#section-login").slideToggle("slow");
        $("#botao-cadastrar").hide();
    } );

}); 

/*slideToggle faz o efeito hide e show, se um aparecer o outro vai se esconder, se um se esconder o outro aparece*/